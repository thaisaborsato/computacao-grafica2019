var searchData=
[
  ['release_20notes',['Release notes',['../news.html',1,'']]]
];
